// notification_ids.dart
int? id1;
int? id2;
int? id3;